import { API_BASE_URL, apiFetch, authHeaders, parseError } from './client';
import { parseGenerateStatusSseFrame } from '../utils/generateSse';

export function enqueueGenerateQuestions(payload, idempotencyKey) {
  return apiFetch('/generate/questions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      ...(idempotencyKey ? { 'Idempotency-Key': idempotencyKey } : {}),
    },
    body: JSON.stringify(payload),
  });
}

export function getGenerateStatus(jobId, options = {}) {
  return apiFetch(`/generate/status/${jobId}`, options);
}

export function cancelGenerateJob(jobId) {
  return apiFetch(`/generate/status/${jobId}/cancel`, { method: 'POST' });
}

export async function streamGenerateStatus(jobId, options = {}) {
  const {
    signal,
    timeoutMs = 20 * 60 * 1000,
    terminal = ['completed', 'failed', 'cancelled'],
    onUpdate,
  } = options;
  const controller = new AbortController();
  const abortFromCaller = () => controller.abort(signal?.reason);
  signal?.addEventListener('abort', abortFromCaller, { once: true });
  const timeout = setTimeout(() => controller.abort('timeout'), timeoutMs);

  try {
    const response = await fetch(`${API_BASE_URL}/generate/status/${jobId}/events`, {
      headers: { ...(await authHeaders()), Accept: 'text/event-stream' },
      signal: controller.signal,
    });
    if (!response.ok) await parseError(response);
    if (!response.body) throw new Error('Trình duyệt không hỗ trợ đọc luồng tiến độ');

    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';
    let latest = null;

    while (true) {
      const { value, done } = await reader.read();
      buffer += decoder.decode(value || new Uint8Array(), { stream: !done }).replace(/\r\n/g, '\n');
      const frames = buffer.split('\n\n');
      buffer = frames.pop() || '';

      for (const frame of frames) {
        latest = parseGenerateStatusSseFrame(frame);
        if (!latest) continue;
        onUpdate?.(latest);
        if (terminal.includes(latest.status)) return latest;
      }
      if (done) break;
    }
    throw new Error('Luồng tiến độ kết thúc trước khi job hoàn tất');
  } catch (error) {
    if (signal?.aborted) throw new DOMException('Theo dõi job đã bị hủy', 'AbortError');
    if (controller.signal.aborted && controller.signal.reason === 'timeout') {
      const timeoutError = new Error('Hết thời gian chờ xử lý');
      timeoutError.name = 'TimeoutError';
      throw timeoutError;
    }
    throw error;
  } finally {
    clearTimeout(timeout);
    signal?.removeEventListener('abort', abortFromCaller);
  }
}
