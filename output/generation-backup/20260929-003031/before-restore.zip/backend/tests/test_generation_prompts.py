import unittest
from pathlib import Path
from unittest.mock import patch

from modules.generation.prompt_builder import PromptBuilder


PROMPT_ROOT = Path(__file__).resolve().parents[1] / "prompts"


class GenerationPromptTests(unittest.TestCase):
    def test_generation_loads_current_rules_and_type_structure(self):
        # Exercise file templates independently of an optional database override.
        with patch.object(
            PromptBuilder,
            "_load_template",
            side_effect=lambda key, path: (PROMPT_ROOT / path).read_text(encoding="utf-8"),
        ):
            for question_type in ("trac_nghiem", "dung_sai"):
                with self.subTest(question_type=question_type):
                    prompt = PromptBuilder().build(
                        context="Nội dung: Stack hoạt động theo nguyên tắc LIFO.",
                        bloom_level="2_hieu",
                        question_type=question_type,
                        num_questions=1,
                    )
                    for path in (
                        "question_rule.txt",
                        "quy_dinh_do_kho.txt",
                        "output_format.txt",
                        f"question_structure/{question_type}.txt",
                    ):
                        self.assertIn((PROMPT_ROOT / path).read_text(encoding="utf-8"), prompt)

    def test_output_schema_defines_options_answers_and_difficulty_by_type(self):
        for question_type, option_keys in (("trac_nghiem", list("ABCD")), ("dung_sai", list("AB"))):
            with self.subTest(question_type=question_type):
                schema = PromptBuilder.output_schema(question_type)
                fields = schema["properties"]["questions"]["items"]["properties"]
                self.assertEqual(fields["options"]["required"], option_keys)
                self.assertEqual(fields["correct_answer"]["enum"], option_keys)
                self.assertEqual(fields["difficulty"]["enum"], ["de", "trung_binh", "kho"])
                self.assertFalse(fields["options"]["additionalProperties"])
        fields = PromptBuilder.output_schema("dien_khuyet")["properties"]["questions"]["items"]["properties"]
        self.assertEqual(fields["options"], {"type": "null"})
