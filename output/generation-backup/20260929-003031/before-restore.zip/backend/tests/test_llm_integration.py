import json
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from unittest.mock import AsyncMock, MagicMock, patch

from modules.generation.llm.gemini import GeminiProvider
from modules.generation.llm.ollama import OllamaProvider, close_ollama_client
from modules.generation.llm.model_registry import (
    GENERATION_CAPABILITY,
    resolve_direct_model_snapshot,
    resolve_model_snapshot,
)


class FakeOllamaHandler(BaseHTTPRequestHandler):
    last_payload = None

    def do_POST(self):
        content_length = int(self.headers.get("Content-Length", "0"))
        payload = json.loads(self.rfile.read(content_length) or b"{}")
        type(self).last_payload = payload
        generated = json.dumps({"model_received": payload.get("model"), "status": "ok"})
        midpoint = len(generated) // 2
        if self.path.endswith("/api/chat"):
            chunks = [
                {"message": {"role": "assistant", "content": generated[:midpoint]}, "done": False},
                {
                    "message": {"role": "assistant", "content": generated[midpoint:]},
                    "done": True,
                    "done_reason": "stop",
                },
            ]
        else:
            chunks = [
                {"response": generated[:midpoint], "done": False},
                {"response": generated[midpoint:], "done": True, "done_reason": "stop"},
            ]
        body = ("\n".join(json.dumps(chunk) for chunk in chunks) + "\n").encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, _format, *_args):
        return


class OllamaHttpIntegrationTests(unittest.IsolatedAsyncioTestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = ThreadingHTTPServer(("127.0.0.1", 0), FakeOllamaHandler)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join(timeout=5)

    async def asyncTearDown(self):
        await close_ollama_client()

    async def test_provider_calls_ollama_compatible_http_endpoint(self):
        provider = OllamaProvider("fake-model", timeout_seconds=2, num_ctx=8192)
        provider.url = f"http://127.0.0.1:{self.server.server_port}/api/generate"

        result = json.loads(await provider.generate_text("test prompt"))

        self.assertEqual(result["status"], "ok")
        self.assertEqual(result["model_received"], "fake-model")
        self.assertTrue(FakeOllamaHandler.last_payload["stream"])
        self.assertEqual(FakeOllamaHandler.last_payload["options"]["num_ctx"], 8192)
        self.assertEqual(provider.last_response_metadata["done_reason"], "stop")

    async def test_provider_sends_roles_and_schema_to_chat_endpoint(self):
        provider = OllamaProvider("fake-model", timeout_seconds=2, num_ctx=8192)
        provider.url = f"http://127.0.0.1:{self.server.server_port}/api/generate"
        schema = {"type": "object", "properties": {"ok": {"type": "boolean"}}}

        result = json.loads(
            await provider.generate_chat(
                system_prompt="system rules",
                user_prompt="user task",
                output_schema=schema,
            )
        )

        self.assertEqual(result["status"], "ok")
        self.assertTrue(FakeOllamaHandler.last_payload["stream"])
        self.assertEqual(provider.last_response_metadata["done_reason"], "stop")
        self.assertEqual(FakeOllamaHandler.last_payload["messages"][0]["role"], "system")
        self.assertEqual(FakeOllamaHandler.last_payload["messages"][1]["role"], "user")
        self.assertEqual(FakeOllamaHandler.last_payload["format"], schema)
        self.assertNotIn("think", FakeOllamaHandler.last_payload)

    async def test_qwen3_uses_its_own_model_and_disables_thinking(self):
        snapshot = resolve_direct_model_snapshot("qwen3-8b", GENERATION_CAPABILITY)
        self.assertEqual(snapshot["model_name"], "qwen3:8b")
        self.assertIs(snapshot["parameters"]["think"], False)
        provider = OllamaProvider("qwen3:8b", think=snapshot["parameters"]["think"])
        provider.url = f"http://127.0.0.1:{self.server.server_port}/api/generate"

        result = json.loads(await provider.generate_chat(system_prompt="rules", user_prompt="question"))

        self.assertEqual(result["model_received"], "qwen3:8b")
        self.assertIs(FakeOllamaHandler.last_payload["think"], False)

    async def test_ollama_preserves_code_blocks_inside_json_for_both_endpoints(self):
        question = "Trong đoạn mã sau, x bằng bao nhiêu?\n```c\nint x = 1;\n```"
        payload = json.dumps({"questions": [{"question": question}]}, ensure_ascii=False)
        provider = OllamaProvider("fake-model")
        for wrapped in (payload, "```json\n" + payload + "\n```"):
            with patch.object(provider, "_stream_completion", new=AsyncMock(return_value=wrapped)):
                for response in (
                    await provider.generate_text("prompt"),
                    await provider.generate_chat(system_prompt="rules", user_prompt="prompt"),
                ):
                    self.assertEqual(json.loads(response)["questions"][0]["question"], question)


class RemovedModelTests(unittest.TestCase):
    def test_removed_qwen_version_cannot_be_selected_directly(self):
        with self.assertRaisesRegex(ValueError, "đã được gỡ"):
            resolve_direct_model_snapshot("ollama:qwen2.5:7b", GENERATION_CAPABILITY)

    def test_removed_qwen_catalog_record_cannot_be_selected(self):
        database = MagicMock()
        database.ai_models.find_one.return_value = {
            "model_code": "qwen",
            "model_name": "qwen2.5:7b",
            "runtime": "OLLAMA",
            "is_active": True,
        }
        with self.assertRaisesRegex(ValueError, "đã được gỡ"):
            resolve_model_snapshot("qwen", database=database)


class GeminiProviderTests(unittest.IsolatedAsyncioTestCase):
    async def test_gemini_preserves_code_blocks_inside_json(self):
        question = "Cho đoạn mã sau:\n```c\nint x = 1;\n```"
        payload = json.dumps({"questions": [{"question": question}]}, ensure_ascii=False)
        response = MagicMock()
        response.output_text = "```json\n" + payload + "\n```"
        client = MagicMock()
        client.interactions.create.return_value = response
        with (
            patch("modules.generation.llm.gemini.settings.gemini_api_key", "test-key"),
            patch("modules.generation.llm.gemini.genai.Client", return_value=client),
        ):
            result = await GeminiProvider(model_name="gemini-3.6-flash").generate_text("prompt")
        self.assertEqual(json.loads(result)["questions"][0]["question"], question)

    async def test_gemini_3_uses_interactions_api_and_cleans_json_fences(self):
        response = MagicMock()
        response.output_text = '```json\n{"ok": true}\n```'
        client = MagicMock()
        client.interactions.create.return_value = response

        with (
            patch("modules.generation.llm.gemini.settings.gemini_api_key", "test-key"),
            patch("modules.generation.llm.gemini.genai.Client", return_value=client),
        ):
            provider = GeminiProvider(model_name="gemini-3.6-flash", max_output_tokens=2048)
            result = await provider.generate_text("prompt")

        self.assertEqual(result, '{"ok": true}')
        client.interactions.create.assert_called_once()
        client.models.generate_content.assert_not_called()
